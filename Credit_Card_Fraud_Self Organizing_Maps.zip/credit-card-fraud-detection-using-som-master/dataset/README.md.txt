# credit-card-Fraud-Detection
Detecting Fraud in Statlog( Australian Credit Approval) Dataset using Unsupervised Learning.
Specifically, we shall be using a Self-Organizing Maps to detect the credit Anomalies in the dataset.  
